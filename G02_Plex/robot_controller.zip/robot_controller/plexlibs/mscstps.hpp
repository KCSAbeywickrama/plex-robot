#pragma once

#include <webots/Robot.hpp>

#define TIME_STEP 16

using namespace webots;
using namespace std;

namespace mscstps
{
    void run(Robot *robot, int redBall);
}