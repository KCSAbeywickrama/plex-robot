#include <iostream>
#include "vision.hpp"

using namespace std;
namespace vision
{
    void gotoObject()
    {
        cout << "vision:gotoObject()" << endl;
    }
    void mainFunction()
    {
        cout << "vision:mainFunction()" << endl;
    }
}
