#pragma once

namespace vision
{
    void gotoObject();
    void mainFunction();
}